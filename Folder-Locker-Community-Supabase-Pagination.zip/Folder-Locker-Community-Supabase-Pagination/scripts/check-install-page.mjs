import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
const html = await readFile(new URL('../install-page/index.html', import.meta.url), 'utf8');
const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)];
let checked = 0;
for (const [, attributes, source] of scripts) {
  if (/\bsrc\s*=/.test(attributes) || !source.trim()) continue;
  new vm.Script(source, { filename: `install-page-inline-${checked + 1}.js` });
  checked++;
}
if (!checked) throw new Error('No inline JavaScript blocks were found.');
console.log(`Passed: ${checked} inline JavaScript block(s).`);
